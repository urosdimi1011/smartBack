<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TermostatDevice extends Model
{
    protected $table = "termostat_devices";
}
