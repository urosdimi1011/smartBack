<?php

namespace App\Http\Controllers;

class TermostatController extends Controller
{
    //
}
